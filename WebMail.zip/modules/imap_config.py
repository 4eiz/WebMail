
IMAP_SERVERS = {
    "rambler.ru": "imap.rambler.ru",
    "yandex.ru": "imap.yandex.ru",
    "mail.ru": "imap.mail.ru",
    "outlook.com": "imap-mail.outlook.com",
    "hotmail.com": "imap-mail.outlook.com",
    "icloud.com": "imap.mail.me.com",
}

DEFAULT_PORT = 993
